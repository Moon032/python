from django import forms
from django.forms import widgets
from django.contrib.auth.models import User
from myblog.models import CategoryModel

class blogForm(forms.Form):
    title = forms.CharField(max_length=100, label='Enter Title',widget=widgets.TextInput(attrs={'placeholder':'Your Title','class': 'form-control' }))
    body = forms.CharField(max_length=100, label='Enter Body',widget=widgets.TextInput(attrs={'placeholder':'Your Body','class': 'form-control' }))
    image = forms.ImageField(label='Choice Image', required=False,widget=widgets.ClearableFileInput(attrs={'class': 'form-control'}))
    category = forms.ModelChoiceField(queryset=CategoryModel.objects.all(),widget=widgets.Select(attrs={'class': 'form-control'}))