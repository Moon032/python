from django.contrib import admin
from myblog.models import PostModel,CategoryDetailModel,CommentModel,UserDetailModel,CategoryModel
# Register your models here.
admin.site.register(PostModel)

admin.site.register(CategoryDetailModel)

admin.site.register(CommentModel)

admin.site.register(UserDetailModel)

admin.site.register(CategoryModel)