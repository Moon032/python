from unicodedata import category
from django.shortcuts import render

# Create your views here.
from datetime import datetime
from email import contentmanager
from django.shortcuts import render,redirect
from myblog.models import PostModel,CategoryModel,CommentModel
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Q
from myblog.form import blogForm

# Create your views here.
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic


class SignUpView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = "registration/signup.html"
    
def to_home (request):
    return redirect('/blog/list/')

@permission_required('blog.add_postmodel', login_url='login')
def post_create(request):
    if request.method == 'GET':
        category = CategoryModel.objects.all()
        form = blogForm
        return render (request,'postCreate.html',{'form':form})
    if request.method == 'POST':
        form = blogForm(request.POST,request.FILES)
        if form.is_valid():
            posts = PostModel.objects.create(
                title = form.cleaned_data.get('title'),
                body = form.cleaned_data.get('body'),
                image = form.cleaned_data.get('image'),
                author_id = request.user.id,
                category = form.cleaned_data.get('category'),
                created_at = datetime.now()
                )
            posts.save()
            messages.success(request, "The post has been created successfully.")
            return redirect ('/blog/list/')
        else:
            messages.error(request, "Can't create, Something went wrong.")
            return redirect ('/blog/list/')

@permission_required('blog.change_postmodel', login_url='login')
def post_update(request, post_id):
    if request.method == "GET":
        posts = PostModel.objects.get(id=post_id)
        values = {
            'title': posts.title,
            'body': posts.body,
            'author': posts.author,
            'category': posts.category,
            'image': posts.image,
            'created_at': posts.created_at
            }
        form = blogForm(initial=values)
        return render(request, 'postUpdate.html', {"form":form,"posts":posts})
    if request.method == "POST":
        posts = PostModel.objects.get(id=post_id)
        form = blogForm(request.POST,request.FILES)
        if form.is_valid():
            posts.title = form.cleaned_data.get('title')
            posts.body = form.cleaned_data.get('body')
            posts.category = form.cleaned_data.get('category')
            if form.cleaned_data.get('image'):
                posts.image = form.cleaned_data.get('image')
            posts.save()
            messages.success(request, "The post has been updated successfully.")
            return redirect('/blog/list/')
    else:
        messages.success(request, "Can't update, Something went wrong.")
        return redirect('/blog/list/')

@permission_required('blog.view_postmodel', login_url='login')
def post_list(request):
    posts = PostModel.objects.all().order_by('-created_at')
    paginator = Paginator(posts, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request,'postList.html', {"posts": page_obj})

def search_by(request):
    search = request.GET.get('search')
    if search:
        posts = PostModel.objects.filter(
        Q(title__icontains=search) |
        Q(body__icontains=search)
        )
        return render(request, 'postList.html', {'posts': posts})
    else:
        posts = PostModel.objects.all().order_by('-created_at')
        return render(request, 'postList.html', {'posts': posts})
    
@permission_required('blog.view_postmodel', login_url='login')
def Category(request):
    posts = PostModel.objects.filter(category_id=1).order_by('-created_at')
    paginator = Paginator(posts, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request,'postList.html', {"posts": page_obj})

    
@permission_required('blog.view_postmodel', login_url='login')
def post_detail(request, post_id):
    post = PostModel.objects.get(id=post_id)
    cmts = CommentModel.objects.filter(post_id=post_id)
    users = User.objects.all()
    return render(request,'postDetail.html',{'post':post,"users": users,"cmts": cmts})

@permission_required('blog.delete_postmodel', login_url='login')
def post_delete (request, post_id):
    posts = PostModel.objects.get(id=post_id)
    posts.image.delete()
    posts.delete()
    messages.error(request, "The post has been deleted successfully.")
    return redirect ('/blog/list/')

def login_view(request):
    if request.method == "GET":
        return render(request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username = username, password = password)
    if user is not None:
        login(request, user)
        messages.success(request, "You are now logged in as "+ username)
        return redirect('/blog/list/')
    else:
        messages.error(request, "Username or Password is incorrect!")
        return render(request, 'login.html')
    
def logout_view(request):
    logout(request)
    return redirect ('/login/')

def cmt_create(request, post_id):
    comment = CommentModel.objects.create(
        content = request.POST.get('content'),
        author_id = request.user.id,
        post_id = post_id
    )
    comment.save()
    messages.success(request, "Your comment has been created successfully.")
    return redirect (f'/blog/detail/{post_id}/#comment')

def cmt_delete(request,cmt_id,post_id):
    comment = CommentModel.objects.filter(id=cmt_id)
    comment.delete()
    messages.success(request, "Your comment has been deleted successfully.")
    return redirect(f'/blog/detail/{post_id}/#comment')

def cmt_update(request,cmt_id,post_id):
    if request.method == "GET":
        comment = CommentModel.objects.get(id=cmt_id)
        post = PostModel.objects.get(id=post_id)
        return render(request, "cmtUpdate.html", {"comment":comment,"post":post})
    if request.method == "POST":
        comment = CommentModel.objects.get(id=cmt_id)
        comment.content = request.POST.get('content')
        comment.save()
        messages.success(request, "Your comment has been updated successfully.")
        return redirect('/blog/detail/' + str(post_id) + '/#comment')

def custom_404_view(request, exception=None):
    return render(request, '404.html', status=404)

